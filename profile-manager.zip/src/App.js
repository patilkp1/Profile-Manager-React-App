import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react'
import NavBar from './components/NavBar';
import Home from './components/Home';
import profiles from './data/inmemory-data';

export default class App extends Component {

  constructor(){
    super()
    this.profiles=profiles;
  }

  render() {
    return (
      <div className="App">
        <NavBar/>
        <div className="container">
          <Home profiles={this.profiles}/>
        </div>
      </div>
    );
  }

}
