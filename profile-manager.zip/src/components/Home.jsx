import React, {Component} from 'react';
import Card from './Card';

export default class Home extends Component{
    render (){
        return(
            <div className="row">
                <div className="col-md-12"> 
                    <h2> Profiles </h2>
                    {/* <p>{JSON.stringify(this.props.profiles)}</p> */}
                   
                        {this.props.profiles.map((user,index)=> <Card user={user} index={index}/>)}
                   
                    {/* this.props.profiles.map((user,index)=> <Card user={user} index={index}/>); */}
                </div>
            </div>
        );
}
}
