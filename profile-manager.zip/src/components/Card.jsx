function Card(props){
    let profile= props.user;
    return(
        <div className="well well-sm" >
            <div className="row">
                <div className="col-md-4">
                    <img src={ profile.photo} alt={profile.name}
                        className="img-rounded img-responsive image-size" />
                </div>
                <div className="col-md-8">
                    <h4 >{profile.name}
                    </h4>
                    <small>{profile.city}, {profile.country} </small>
                    <p>
                        {profile.email}
                        <br />
                        {profile.birthdate}
                    </p>
                </div>
            </div>
        </div>
    )
}
export default Card;